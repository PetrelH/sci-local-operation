# Shell Agent

macOS 本地 Shell 代理服务，支持通过浏览器远程执行命令，并通过 RabbitMQ 进行加密命令分发。

## 项目结构

```
shellagent/
│
│── 核心服务
├── agent.py                # 本地 HTTP 服务（FastAPI），执行 Shell 命令
├── console.html            # Web 控制台，浏览器直接打开
├── menubar_app.py          # macOS 菜单栏 App（状态栏图标）
│
│── MQ 相关
├── mq_producer_api.py      # MQ 生产者服务：从 MySQL 读取任务，AES 加密后发到 RabbitMQ
├── mq_consumer.py          # MQ 消费者：从队列取命令，解密后执行，结果回写
├── mq_sender.py            # 手动发送工具（调试用）
│
│── 数据库
├── init.sql                # MySQL 建表 SQL
│
│── 打包 & 安装
├── build_pkg.py            # macOS .pkg 打包脚本
├── install.sh              # macOS 一键安装入口
├── install-windows.ps1     # Windows 一键安装入口
├── preflight_check.sh      # macOS 打包前环境预检
└── uninstall.sh            # macOS 卸载脚本
```

---

## 快速开始

### 本地调试（不打包）

```bash
pip install fastapi uvicorn
python3 agent.py
# 访问 http://localhost:8000
# 直接打开 console.html 使用 Web 控制台
```

### MQ 生产者服务

```bash
pip install fastapi uvicorn pika cryptography pymysql sqlalchemy apscheduler

# 生成 AES 密钥
export AES_KEY="$(python3 -c 'import os,base64; print(base64.b64encode(os.urandom(32)).decode())')"
export MQ_HOST=your-rabbitmq-host
export DB_HOST=your-mysql-host  DB_USER=root  DB_PASS=xxx  DB_NAME=shellagent

# 初始化数据库（首次）
python3 mq_producer_api.py --init-db

# 启动服务（默认端口 9000，每 5 分钟轮询数据库）
python3 mq_producer_api.py
```

### MQ 消费者（Mac 本地）

```bash
pip install pika cryptography

export MQ_HOST=your-rabbitmq-host
export MQ_USER_ID=user123
export AES_KEY="同上密钥"

python3 mq_consumer.py
# 监听 agent.user123 队列，收到命令自动执行
```

### macOS 打包成 .pkg

```bash
pip install pyinstaller rumps pyobjc-framework-Cocoa
./install.sh
# 输出 ShellAgent-1.0.0.pkg，双击安装
```

---

## 环境变量汇总

### agent.py
| 变量 | 默认值 | 说明 |
|------|--------|------|
| AGENT_TOKEN | my-secret-token | 接口鉴权 Token |
| AGENT_HOST | 0.0.0.0 | 监听地址 |
| AGENT_PORT | 8000 | 监听端口 |

### mq_producer_api.py
| 变量 | 默认值 | 说明 |
|------|--------|------|
| MQ_HOST/PORT/USER/PASS/VHOST | localhost/5672/guest/guest// | RabbitMQ 连接 |
| DB_HOST/PORT/USER/PASS/NAME | localhost/3306/root//shellagent | MySQL 连接 |
| AES_KEY | — | AES-256 密钥 base64（必填）|
| API_TOKEN | producer-secret | 接口鉴权 |
| API_PORT | 9000 | 服务端口 |
| POLL_INTERVAL | 300 | 数据库轮询间隔（秒）|

### mq_consumer.py
| 变量 | 默认值 | 说明 |
|------|--------|------|
| MQ_HOST/PORT/USER/PASS/VHOST | localhost/5672/guest/guest// | RabbitMQ 连接 |
| MQ_USER_ID | — | 当前用户ID（必填）|
| AES_KEY | — | AES-256 密钥 base64（必填）|

---

## API 接口

### agent.py（本地服务，端口 8000）
| 方法 | 路径 | 说明 |
|------|------|------|
| GET  | / | 健康检查 |
| POST | /exec | 执行命令（同步）|
| POST | /exec/stream | 执行命令（流式 SSE）|
| GET  | /cwd | 查询当前工作目录 |
| POST | /cwd | 设置工作目录 |
| GET  | /grant-access | 打开系统设置授权页 |

### mq_producer_api.py（生产者服务，端口 9000）
| 方法 | 路径 | 说明 |
|------|------|------|
| GET  | /health | 健康检查 |
| POST | /send | 提交单条命令 |
| POST | /send/batch | 批量提交命令 |
| GET  | /tasks | 查询任务列表 |
| GET  | /tasks/{id} | 查询单条任务 |
| POST | /tasks/{id}/retry | 重试失败任务 |
| POST | /poll/trigger | 手动触发轮询 |
| POST | /gen-key | 生成 AES 密钥 |

---

## 数据流

```
外部系统
  │ POST /send
  ▼
mq_producer_api（端口 9000）
  │ 写入 MySQL command_tasks
  │ 每 5 分钟轮询 pending 任务
  │ AES-256-CBC 加密
  ▼
RabbitMQ → agent.{user_id} 队列
                │
         mq_consumer（Mac 本地）
                │ 解密 → 执行命令
                │ 加密结果
                ▼
         result.{user_id} 队列
```
